const { console, prepare, errorHandler, isValid } = require('../../helpers');
const createError = require('http-errors');
const satelize = require('satelize');
const http = require('http');
const mysql = require('mysql');
const axios = require('axios');
const connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'wigdb'
});
connection.connect();
class UtilitiesController {
	constructor() {
		console('utilities controller created');
	}

	async updatedata(req, res,next){

		const apiEndpoint = 'https://api.exchangerate-api.com/v4/latest/USD'; // Replace with your desired API endpoint
		axios.get(apiEndpoint)
		  .then((response) => {
		    const rates = response.data.rates;
		    const usdToBdtRate = Math.round(rates['BDT']); // Replace 'EUR' with your desired currency code
		    console(`USD to BDT rate: ${usdToBdtRate}`);

		    // Add the currency rate to the MySQL database
		    const query = `UPDATE currency SET rate = ${usdToBdtRate} where currency_code ='BDT'`;
		    connection.query(query, (error, results, fields) => {
		      if (error) {
		        console('Error inserting currency rate into database:', error);
		      } else {
		        console('Currency rate added to database');
		        	
		      }
		    });
		  })
		  .catch((error) => {
		    console('Error retrieving currency rate:', error);
		  });
		   res.end('Currency rate added to database');
	
	}

	async geodata(req, res,next){
			
		try{
			//const ip = req.connection.remoteAddress;
				const ip ='103.19.255.86';
			console(`Client IP address: ${ip}`);
			satelize.satelize({ip:ip}, function(err,payload){
				console(payload);
				

				if(payload.country_code == 'BD')
				{
					const sql = 'SELECT * FROM currency WHERE country_code = ?';
						connection.query(sql, ['BD'], function (error, results, fields) {
							  if (error) throw error;

							  // Log the result to the console
							  console(results[0]['rate']);
							  const responseData = {
								'currency': 'BDT',
								'currency_rate': results[0]['rate'],
								 }
								  const jsonContent = JSON.stringify(responseData);
		  				 		 res.end(jsonContent);
							});
					
					
				}
				else
				{
					const responseData = {
						'currency': '$',
						'currency_rate': '1',
						 }
						  const jsonContent = JSON.stringify(responseData);
  				 res.end(jsonContent);
				}
				
				//result.country = payload.country_code;
				});

				
		}
		catch(err){
			console(err.message)
			return next(err);
		}
	}

	
}

module.exports = new UtilitiesController();
