

module.exports = {
	ProductController: require('./products/product.controller'),
	AttributesController: require('./attributes/Attributes.controller'),
	AttributeValuesController: require('./attributes/AttributeValues.controller'),
	UsersController:  require('./users/Users.controller'),
	ProductCatController: require('./products/product-cat.controller'),
	UtilitiesController: require('./utilities/utilities.controller')
}