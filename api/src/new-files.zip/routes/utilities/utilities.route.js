const { Router } = require('express');
const router = Router();

const { UtilitiesController } = require('../../controllers');
const {  Auth, Admin, } = require('../../middleware');

router
.get('/',UtilitiesController.geodata)
.get('/update',UtilitiesController.updatedata)


module.exports = router;